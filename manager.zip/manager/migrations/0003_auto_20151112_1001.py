# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ('manager', '0002_auto_20151112_0227'),
    ]

    operations = [
        migrations.CreateModel(
            name='Cor_user_Power',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('temp_1', models.CharField(max_length=32, null=True)),
                ('temp_2', models.CharField(max_length=32, null=True)),
                ('temp_3', models.CharField(max_length=32, null=True)),
                ('temp_4', models.CharField(max_length=32, null=True)),
            ],
        ),
        migrations.CreateModel(
            name='Power',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('temp_1', models.CharField(max_length=32, null=True)),
                ('temp_5', models.CharField(max_length=32, null=True)),
                ('temp_2', models.CharField(max_length=32, null=True)),
                ('temp_3', models.CharField(max_length=32, null=True)),
                ('temp_4', models.CharField(max_length=32, null=True)),
                ('name', models.ForeignKey(blank=True, to=settings.AUTH_USER_MODEL, null=True)),
            ],
        ),
        migrations.RemoveField(
            model_name='cor_user_jurisdiction',
            name='JurisdictionID',
        ),
        migrations.RemoveField(
            model_name='cor_user_jurisdiction',
            name='UserID',
        ),
        migrations.RemoveField(
            model_name='jurisdiction',
            name='name',
        ),
        migrations.DeleteModel(
            name='Cor_user_Jurisdiction',
        ),
        migrations.DeleteModel(
            name='Jurisdiction',
        ),
        migrations.AddField(
            model_name='cor_user_power',
            name='PowerID',
            field=models.ForeignKey(blank=True, to='manager.Power', null=True),
        ),
        migrations.AddField(
            model_name='cor_user_power',
            name='UserID',
            field=models.ForeignKey(blank=True, to=settings.AUTH_USER_MODEL, null=True),
        ),
    ]
