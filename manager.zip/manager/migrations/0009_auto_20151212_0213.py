# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('manager', '0008_auto_20151212_0137'),
    ]

    operations = [
        migrations.RenameField(
            model_name='cor_rule_power',
            old_name='RueID',
            new_name='RuleID',
        ),
    ]
