# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('manager', '0005_auto_20151116_2142'),
    ]

    operations = [
        migrations.RenameField(
            model_name='department',
            old_name='temp_1',
            new_name='level',
        ),
    ]
