# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='Cor_Depart_role',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('temp_1', models.CharField(max_length=32, null=True)),
                ('temp_2', models.CharField(max_length=32, null=True)),
                ('temp_3', models.CharField(max_length=32, null=True)),
                ('temp_4', models.CharField(max_length=32, null=True)),
            ],
        ),
        migrations.CreateModel(
            name='Cor_role_user_depart',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('UserID', models.CharField(max_length=32, null=True)),
                ('temp_1', models.CharField(max_length=32, null=True)),
                ('temp_2', models.CharField(max_length=32, null=True)),
                ('temp_3', models.CharField(max_length=32, null=True)),
                ('temp_4', models.CharField(max_length=32, null=True)),
                ('Cor_Department_and_role_ID', models.ForeignKey(blank=True, to='manager.Cor_Depart_role', null=True)),
            ],
        ),
        migrations.CreateModel(
            name='Department',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('name', models.CharField(max_length=32, null=True)),
                ('temp_1', models.CharField(max_length=32, null=True)),
                ('temp_2', models.CharField(max_length=32, null=True)),
                ('temp_3', models.CharField(max_length=32, null=True)),
                ('temp_4', models.CharField(max_length=32, null=True)),
                ('superior_department', models.ForeignKey(blank=True, to='manager.Department', null=True)),
            ],
        ),
        migrations.CreateModel(
            name='Roles',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('name', models.CharField(max_length=32, null=True)),
                ('temp_1', models.CharField(max_length=32, null=True)),
                ('temp_2', models.CharField(max_length=32, null=True)),
                ('temp_3', models.CharField(max_length=32, null=True)),
                ('temp_4', models.CharField(max_length=32, null=True)),
                ('superior_role', models.ForeignKey(blank=True, to='manager.Roles', null=True)),
            ],
        ),
        migrations.AddField(
            model_name='cor_depart_role',
            name='DepartmentID',
            field=models.ForeignKey(blank=True, to='manager.Department', null=True),
        ),
        migrations.AddField(
            model_name='cor_depart_role',
            name='roleID',
            field=models.ForeignKey(blank=True, to='manager.Roles', null=True),
        ),
    ]
