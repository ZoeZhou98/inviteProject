#encoding=UTF-8
from django import forms
from django.forms import ModelForm
from manager.models import Roles,Rule,Department,Power,Cor_role_user_depart,Cor_user_Power,Email
from accounts.models import MyUser
class DepartmentForm(ModelForm): 
    name = forms.CharField(max_length=32,required=True,error_messages={'required': u'部门名称不能为空','unique':'重复'},label=u'* 部门名称 ')
    superior_department = forms.ModelChoiceField(queryset=Department.objects.all(),label=u'上级部门 ',required = False)
    class Meta:
        model = Department
        fields=('name','superior_department') 
        
class RoleForm(ModelForm):
     name = forms.CharField(max_length=32,required=True,error_messages={'required': u'职位名称不能为空'},label=u'* 角色名称 ')
     DepartmentID = forms.ModelChoiceField(queryset=Department.objects.all(),label=u'* 部门名称 ',required = True,error_messages={'required': u'所处部门不能为空'})
     superior_role = forms.ModelChoiceField(queryset=Roles.objects.all(),label=u'上级职位 ',required = False)
     class Meta:
        model = Roles
        fields=('name','superior_role','DepartmentID')
class PowerForm(ModelForm): 
    name = forms.CharField(max_length=32,required=True,error_messages={'required': u'权限名称不能为空'},label=u'* 权限名称 ')
    class Meta:
        model = Power
        fields=('name',)
    
class Cor_role_user_departForm(ModelForm): 
    UserID = forms.ModelChoiceField(queryset=MyUser.objects.all(),label=u'* 用户名 ',required = True,error_messages={'required': u'用户名不能为空'})
    RoleID = forms.ModelChoiceField(queryset=Roles.objects.all(),label=u'* 职位 ',required = True,error_messages={'required': u'职位不能为空'})
    class Meta:
        model = Cor_role_user_depart
        fields=('UserID','RoleID')
class Cor_user_powerForm(ModelForm):
    UserID = forms.ModelChoiceField(queryset=MyUser.objects.all(),label=u'* 用户名 ',required = True,error_messages={'required': u'用户名不能为空'})
    PowerID = forms.ModelChoiceField(queryset=Power.objects.all(),label=u'* 权限名',required = True,error_messages={'required': u'权限名不能为空'})
    class Meta:
        model = Cor_user_Power
        fields=('UserID','PowerID')
class EmailForm(ModelForm):
    mail = forms.EmailField(required=True,label=u'*邮箱',error_messages={'required': u'邮箱不能为空'})
    password=forms.CharField(required=True,label=u'*密码',error_messages={'required': u'密码不能为空'},widget=forms.PasswordInput(attrs={'placeholder':u"密码"}))
    class Meta:
        model = Email
        fields=('mail','password')
class RuleForm(ModelForm):
    name = forms.CharField(max_length=32,required=True,error_messages={'required': u'角色名称不能为空'},label=u'* 角色名称 ')
    PowerID = forms.ModelMultipleChoiceField(queryset=Power.objects.all(),label=u'* 职位',widget=forms.CheckboxSelectMultiple,required = True,error_messages={'required': u'权限不可以为空'})
    class Meta:
        model = Rule
        fields=('name','PowerID')
